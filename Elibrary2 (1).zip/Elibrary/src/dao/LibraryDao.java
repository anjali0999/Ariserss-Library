package dao;
import java.sql.*;
import java.io.*;
import java.util.*;
import model.Library;
	public class LibraryDao 
	{
		private PreparedStatement pst;
		private String sql;
		private Connection con;
		private ResultSet res;
		public LibraryDao() throws ClassNotFoundException,SQLException,IOException
		{
				Class.forName("com.mysql.jdbc.Driver");
				con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","");
		}
    	public Integer addRecord(Library l)throws SQLException
	{
		sql="insert into Library values(?,?,?,?)";
		pst=con.prepareStatement(sql);
		pst.setInt(1,l.getBookId());
    	pst.setString(2, l.getBookName());
    	pst.setString(3,l.getAuthorName());
    	pst.setString(4,l.getBookMedium());
    	return pst.executeUpdate();
   }
    	public Integer deleteRecord(Library l) throws SQLException
	    {  
	    	sql="delete from Library where id=?";
	    	pst=con.prepareStatement(sql);
	    	pst.setInt(1,l.getBookId());  
	    	return pst.executeUpdate();
	    }
	    public Integer updateRecord(Library l) throws SQLException
	    {  
	    	sql="update Library set bookname=?,authorname=?,bookmedium=? where bookid=?";
	    	pst=con.prepareStatement(sql);
	    	pst.setInt(4,l.getBookId());
	    	pst.setString(1, l.getBookName());
	    	pst.setString(2,l.getAuthorName());
	    	pst.setString(3,l.getBookMedium());
	    	
	    	return pst.executeUpdate();
	    }
	    public List<Library> findAllRecord() throws SQLException
	    {
	    	sql="select *from Library";
	    	pst=con.prepareStatement(sql);
	    	res=pst.executeQuery();
	    	List<Library> store=new ArrayList<Library>();
	    	while(res.next()==true)
	    	{
	    		Library l =new Library();
	    		l.setBookId(res.getInt(1));
	    		l.setBookName(res.getString(2));
	    	    l.setAuthorName(res.getString(3));
	    	    l.setBookMedium(res.getString(4));
	    		store.add(l);
	    	}
	    	
	    	return store;
	    }
   }