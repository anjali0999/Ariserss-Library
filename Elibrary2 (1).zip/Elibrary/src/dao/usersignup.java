package dao;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.Usersign1;
public class UsersignDao1 {

	private PreparedStatement pst;
	private String sql;
	private Connection con;
	private ResultSet res;
	 
	public UsersignDao1() throws ClassNotFoundException,SQLException,IOException
	{
			//Class.forName("com.mysql.jdbc.Driver");
			//con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","");
	}
	public Boolean validate(Usersign1 u) throws SQLException
	{
		sql="select * from Usersign1 where username=?  , email=? , npassword=? and cpassword=?";
		pst=con.prepareStatement(sql);
		pst.setString(1,u.getUsername());
		pst.setString(2,u.getEmail());
		pst.setString(3,u.getcPassword());
		pst.setString(4,u.getnPassword());
		res=pst.executeQuery();
		if(res.next())
			return true;
		else
			return false;
	}
}