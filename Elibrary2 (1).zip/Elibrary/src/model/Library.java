package model;
public class Library {
	private Integer BookId;
	private String BookName;
	private String AuthorName;
	private String BookMedium;
	public Integer getBookId() {
		return BookId;
	}
	public void setBookId(Integer bookId) {
		BookId = bookId;
	}
	public String getBookName() {
		return BookName;
	}
	public void setBookName(String bookName) {
		BookName = bookName;
	}
	public String getAuthorName() {
		return AuthorName;
	}
	public void setAuthorName(String authorName) {
		AuthorName = authorName;
	}
	public String getBookMedium() {
		return BookMedium;
	}
	public void setBookMedium(String bookMedium) {
		BookMedium = bookMedium;
	}
}
