package model;
public class Usersign1 {
private String username;
private String email;
private String  npassword;
private String cpassword;
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getNpassword() {
	return npassword;
}
public void setNpassword(String npassword) {
	this.npassword = npassword;
}
public String getCpassword() {
	return cpassword;
}
public void setCpassword(String cpassword) {
	this.cpassword = cpassword;
}

}